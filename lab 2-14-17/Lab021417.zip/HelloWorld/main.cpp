/* 
 * File:   main.cpp
 * Author: Nguyen, Alex
 * Created on February 14, 2017, 11:29 AM
 * Purpose: Template to be utilized in creating 
 * solutions to problems in our CSC/CIS 5 class.
 */

//System Libraries
#include <iostream>//Input - Output Library

using namespace std; //Namespace under which system libraries exist.

//User LIbraries

//Global Constants

//Function Prototypes 

//Execution begins here
int main(int argc, char** argv) {
    //declare variables
  
    //Initialize variables
   
    //Input data
    
            
    //Map inputs to outputs or process the data
    
    //Output the transformed data
    cout<<"Hello World."<<endl;
    //Exit stage right
    return 0;
}

